let multiply = {
   (no1: Int, no2: Int) -> Int in
   return no1 * no2
}

let digits = multiply(9, 4)
print(digits)
